import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import json, os, random, string, threading
from datetime import datetime

# =============== CONFIG =================
BOT_TOKEN = "8344356744:AAEs-cz3nTdzWlrVO-7DiTlZKBiFOD0XYHg"
OWNER_ID = 6061265721
LOG_GROUP_ID = -1003679846133

DATA_FILE = "data.json"
USERS_FILE = "users.json"
AUTO_DELETE_SECONDS = 1200

bot = telebot.TeleBot(BOT_TOKEN)
BOT_USERNAME = None
admin_state = {}

# =============== DB HELPERS =================

def load_db():
    default = {
        "files": {},
        "force_channels": [],
        "admins": [OWNER_ID]
    }

    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, "w") as f:
            json.dump(default, f, indent=2)
        return default

    try:
        with open(DATA_FILE, "r") as f:
            db = json.load(f)
    except:
        db = default

    for k, v in default.items():
        if k not in db:
            db[k] = v

    with open(DATA_FILE, "w") as f:
        json.dump(db, f, indent=2)

    return db


def save_db(db):
    with open(DATA_FILE, "w") as f:
        json.dump(db, f, indent=2)


def load_users():
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, "w") as f:
            json.dump({}, f)
    with open(USERS_FILE, "r") as f:
        return json.load(f)


def save_users(users):
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=2)

# =============== USERS =================

def register_user(user):
    users = load_users()
    uid = str(user.id)

    if uid not in users:
        users[uid] = {
            "name": user.first_name,
            "username": user.username,
            "time": datetime.now().strftime("%d-%m-%Y %H:%M")
        }
        save_users(users)

        bot.send_message(
            LOG_GROUP_ID,
            f"🆕 New User Joined\n\n"
            f"👤 Name: {user.first_name}\n"
            f"🆔 ID: {user.id}\n"
            f"🔗 Username: @{user.username if user.username else 'None'}\n"
            f"⏰ Time: {users[uid]['time']}"
        )

# =============== HELPERS =================

def is_admin(uid):
    db = load_db()
    return uid == OWNER_ID or uid in db["admins"]

def gen_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

def auto_delete(cid, mid):
    threading.Timer(AUTO_DELETE_SECONDS, lambda: bot.delete_message(cid, mid)).start()

# =============== FORCE JOIN =================

def joined_all(uid):
    db = load_db()
    for ch in db["force_channels"]:
        try:
            m = bot.get_chat_member(ch["chat_id"], uid)
            if m.status not in ["member", "administrator", "creator"]:
                return False
        except:
            return False
    return True

def force_kb():
    kb = InlineKeyboardMarkup()
    for ch in load_db()["force_channels"]:
        kb.add(InlineKeyboardButton(ch["name"], url=ch["invite"]))
    kb.add(InlineKeyboardButton("✅ I Joined", callback_data="CHECK_JOIN"))
    return kb

# =============== START =================

@bot.message_handler(commands=["start"])
def start(message):
    register_user(message.from_user)

    args = message.text.split(maxsplit=1)
    if len(args) == 2:
        send_file(message.chat.id, message.from_user.id, args[1])
        return

    if not joined_all(message.from_user.id):
        bot.send_message(message.chat.id, "❌ Join all channels", reply_markup=force_kb())
        return

    bot.send_message(message.chat.id, "👋 Send a file")

# =============== FILE SEND =================

def send_file(chat_id, uid, code):
    db = load_db()

    if not joined_all(uid):
        bot.send_message(chat_id, "❌ Join required channels", reply_markup=force_kb())
        return

    if code not in db["files"]:
        bot.send_message(chat_id, "❌ Invalid or expired link")
        return

    f = db["files"][code]
    caption = "⚠️ This file will be deleted in 20 minutes."

    t, fid = f["type"], f["file_id"]
    if t == "document":
        msg = bot.send_document(chat_id, fid, caption=caption)
    elif t == "video":
        msg = bot.send_video(chat_id, fid, caption=caption)
    elif t == "photo":
        msg = bot.send_photo(chat_id, fid, caption=caption)
    elif t == "audio":
        msg = bot.send_audio(chat_id, fid, caption=caption)
    else:
        msg = bot.send_voice(chat_id, fid, caption=caption)

    auto_delete(chat_id, msg.message_id)

# =============== UPLOAD =================

@bot.message_handler(content_types=["document","video","photo","audio","voice"])
def upload(message):
    if not joined_all(message.from_user.id):
        bot.send_message(message.chat.id, "❌ Join required channels", reply_markup=force_kb())
        return

    db = load_db()

    if message.document:
        t, fid = "document", message.document.file_id
    elif message.video:
        t, fid = "video", message.video.file_id
    elif message.photo:
        t, fid = "photo", message.photo[-1].file_id
    elif message.audio:
        t, fid = "audio", message.audio.file_id
    else:
        t, fid = "voice", message.voice.file_id

    code = gen_code()
    db["files"][code] = {"type": t, "file_id": fid}
    save_db(db)

    bot.reply_to(message, f"🔗 https://t.me/{BOT_USERNAME}?start={code}")

# =============== ADMIN PANEL =================

@bot.message_handler(commands=["admin"])
def admin_panel(message):
    if not is_admin(message.from_user.id):
        return

    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("📢 Broadcast", callback_data="BC"),
        InlineKeyboardButton("➕ Add Channel", callback_data="ADD_CH"),
        InlineKeyboardButton("➖ Remove Channel", callback_data="DEL_CH"),
        InlineKeyboardButton("👑 Add Admin", callback_data="ADD_ADM"),
        InlineKeyboardButton("❌ Remove Admin", callback_data="DEL_ADM"),
        InlineKeyboardButton("📊 Total Users", callback_data="ST_USERS"),
        InlineKeyboardButton("📁 Total Files", callback_data="ST_FILES")
    )
    bot.send_message(message.chat.id, "👑 Admin Panel", reply_markup=kb)

# =============== ADMIN CALLBACK =================

@bot.callback_query_handler(func=lambda c: True)
def callbacks(call):
    uid = call.from_user.id
    if not is_admin(uid):
        return

    db = load_db()

    if call.data == "ST_USERS":
        bot.answer_callback_query(call.id, f"Total Users: {len(load_users())}", True)

    elif call.data == "ST_FILES":
        bot.answer_callback_query(call.id, f"Total Files: {len(db['files'])}", True)

    elif call.data == "BC":
        admin_state[uid] = "broadcast"
        bot.send_message(uid, "Send broadcast message")

    elif call.data == "ADD_CH":
        admin_state[uid] = "add_ch"
        bot.send_message(uid, "Name | ChatID | InviteLink")

    elif call.data == "ADD_ADM":
        admin_state[uid] = "add_adm"
        bot.send_message(uid, "Send user ID")

    elif call.data == "DEL_ADM":
        admin_state[uid] = "del_adm"
        bot.send_message(uid, "Send admin ID")

    elif call.data == "DEL_CH":
        kb = InlineKeyboardMarkup()
        for i, ch in enumerate(db["force_channels"]):
            kb.add(InlineKeyboardButton(ch["name"], callback_data=f"RCH_{i}"))
        bot.send_message(uid, "Select channel", reply_markup=kb)

    elif call.data.startswith("RCH_"):
        idx = int(call.data.split("_")[1])
        ch = db["force_channels"].pop(idx)
        save_db(db)
        bot.edit_message_text(f"Removed {ch['name']}", call.message.chat.id, call.message.message_id)

# =============== ADMIN TEXT =================

@bot.message_handler(func=lambda m: m.from_user.id in admin_state)
def admin_text(message):
    uid = message.from_user.id
    mode = admin_state.pop(uid)
    db = load_db()

    if mode == "broadcast":
        c = 0
        for u in load_users():
            try:
                bot.send_message(int(u), message.text)
                c += 1
            except:
                pass
        bot.reply_to(message, f"Sent to {c} users")

    elif mode == "add_ch":
        n, i, l = [x.strip() for x in message.text.split("|")]
        db["force_channels"].append({"name": n, "chat_id": int(i), "invite": l})
        save_db(db)
        bot.reply_to(message, "Channel added")

    elif mode == "add_adm":
        i = int(message.text)
        if i not in db["admins"]:
            db["admins"].append(i)
            save_db(db)
        bot.reply_to(message, "Admin added")

    elif mode == "del_adm":
        i = int(message.text)
        if i != OWNER_ID and i in db["admins"]:
            db["admins"].remove(i)
            save_db(db)
        bot.reply_to(message, "Admin removed")

# =============== RUN =================

if __name__ == "__main__":
    BOT_USERNAME = bot.get_me().username
    print("Bot running as", BOT_USERNAME)
    bot.infinity_polling(skip_pending=True)